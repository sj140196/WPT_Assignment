const url="";
let dbparams=
{
    host: 'localhost',
    user: 'root',
    password: 'cdac',
    database: 'ratnagiri',
	port:5500
}; 


const mysql = require('mysql2');
const con=mysql.createConnection(parameter);

let  itemno=1;  
con.query('select itemno, intname,  price,category from item where  itemno=?', [ itemno], 
(err, rows) => {
    if (err) {
        console.log("error has occured we have to check");  
    } else {
        if(rows.length > 0)
          console.log(rows[0].itemno + " " + rows[0].intname + " " + rows[0].price + " "+rows[0].category);
        else
           console.log("NO employee found with "+ empno);
    
        }
}
);
