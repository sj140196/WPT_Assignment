const url="";
let dbparams=
{
    host: 'localhost',
    user: 'root',
    password: 'cdac',
    database: 'ratnagiri',
	port:5500
};
const mysql = require('mysql2');
const con=mysql.createConnection(parameter);

let price =500;

let category = 'Food';
let itemno = 3;

con.query('update  item set price =?,category =? where itemno=? ', [price,category,itemno], 
(err,res1) => {
    if (err) {
        console.log("error has occured let us see");  
    } else {
        if(res1.affectedRows===0)
        {
            console.log("update failed");
        } 
        else
           console.log("update suceeded");    
       
    }
}
);
