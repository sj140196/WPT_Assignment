
let dbparams=
{
    host: 'localhost',
    user: 'root',
    password: 'cdac',
    database: 'ratnagiri',
	port:5500
}; 

const mysql = require('mysql2'); 
const con=mysql.createConnection(parameter);



let category='stationary';  
con.query('select itemno, intname, price,category from item where category=?', [category], 
(err, rows) => {
    if (err) {
        console.log("error has occured we have to check ");  
    } else {
        if(rows.length > 0)
        {
            for(let i=0; i < rows.length; i++)
            console.log(rows[i].itemno + " " + rows[i].intname + " " + rows[i].price + " " +rows[i].category);
        }
            else
           console.log("No employee found with "+ itemno);
    
        }
}
);
