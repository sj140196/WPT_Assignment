const url="";
let dbparams=
{
    host: 'localhost',
    user: 'root',
    password: 'cdac',
    database: 'ratnagiri',
	port:5500
};
const mysql = require('mysql2');
const con=mysql.createConnection(parameter);


let itemno = 4;
let intname = 'Souce';
let price =600;
let category = 'Extras';
con.query('insert into item(itemno,intname,price,category) values (?,?,?,?)', [itemno,intname,price,category], 
(err, res1) => {
    if (err) {
        console.log("error has occured we have to check");  
    } else {
        console.log(res1.affectedRows)     
       
    }
}
);


