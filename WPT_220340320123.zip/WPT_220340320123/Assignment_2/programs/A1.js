const url="";
let data={
    host:"localhost",
    user:"root",
    password:"cdac",
    database:"ratnagiri",
    port:5500
};
const mysql =require('mysql2');
const con=mysql.createConnection(data);

console.log("Database gets Connected");